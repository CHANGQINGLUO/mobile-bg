/**
 * Copyright (C) 2014 My Company. All Rights Reserved. 
 * 
 * This software is the proprietary information of Company . 
 * Use is subjected to license terms. 
 *
 * @since 11 Jun, 2014 9:30:49 am
 * @author SPA
 * @mb-bg-fw-core
 *
 */
package com.mb.framework.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "SYS_ENUM")
public class EnumEntity extends AbstractBaseEntity
{
	private static final long serialVersionUID = 4389710124821962658L;
	
	@Id @GeneratedValue(generator="ENUM_UUID")
	@GenericGenerator(name="ENUM_UUID", strategy = "uuid")
	@Column(name = "ENUM_UUID",length = 100)
	private String uuid;
	
	@Column(name = "MESSAGE_KEY",nullable = false, length = 13)
	private String messageKey;
	
	@Column(name = "CATEGORY",length = 18)
	private String category;
	
	@Column(name = "RANKING")
	private int ranking;

	/**
	 * @return the uuid
	 */
	public String getUuid() {
		return uuid;
	}

	/**
	 * @param uuid the uuid to set
	 */
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	/**
	 * @return the messageKey
	 */
	public String getMessageKey() {
		return messageKey;
	}

	/**
	 * @param messageKey the messageKey to set
	 */
	public void setMessageKey(String messageKey) {
		this.messageKey = messageKey;
	}

	/**
	 * @return the category
	 */
	public String getCategory() {
		return category;
	}

	/**
	 * @param category the category to set
	 */
	public void setCategory(String category) {
		this.category = category;
	}

	/**
	 * @return the ranking
	 */
	public int getRanking() {
		return ranking;
	}

	/**
	 * @param ranking the ranking to set
	 */
	public void setRanking(int ranking) {
		this.ranking = ranking;
	}

	/**
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	
}
