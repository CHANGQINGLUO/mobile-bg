/**
 * Copyright (C) 2014 My Company. All Rights Reserved. 
 * 
 * This software is the proprietary information of Company . 
 * Use is subjected to license terms. 
 *
 * @since 17 Dec, 2014 7:18:35 pm
 * @author SPA
 * @mb-bg-fw-core
 * LocaleConstant.java
 *
 */
package com.mb.framework.constant;

/**
 * @author SPA
 *
 */
public class LocaleConstant {
	
	public static final String DEFAULT = "en";

}
