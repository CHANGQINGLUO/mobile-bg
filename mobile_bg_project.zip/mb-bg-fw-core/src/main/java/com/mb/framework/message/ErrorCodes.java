/**
 * Copyright (C) 2014 My Company. All Rights Reserved. 
 * 
 * This software is the proprietary information of Company . 
 * Use is subjected to license terms. 
 *
 * @since 13 Jun, 2014 3:08:34 pm
 * @author SPA
 * @mb-bg-fw-core
 *
 */
package com.mb.framework.message;

public class ErrorCodes
{
	public static final String FM00001 = "FM00001";
	public static final String FM00002 = "FM00002";
	public static final String FM00003 = "FM00003";
	public static final String FM00004 = "FM00004";
	public static final String FM00005 = "FM00005";
	public static final String FM00006 = "FM00006";
	public static final String FM00007 = "FM00007";
	public static final String FM00008 = "FM00008";
	public static final String FM00009 = "FM00009";
	public static final String FM00010 = "FM00010";
	public static final String FM00011 = "FM00011";
	public static final String FM00012 = "FM00012";
	public static final String FM00013 = "FM00013";
	public static final String FM00014 = "FM00014";
	public static final String FM00015 = "FM00015";
	public static final String FM00016 = "FM00016";
	public static final String FM00017 = "FM00017";
	public static final String FM00018 = "FM00018";
	public static final String FM00019 = "FM00019";
	public static final String FM00020 = "FM00020";
	public static final String FM00021 = "FM00021";
	public static final String FM00022 = "FM00022";
	public static final String FM00023 = "FM00023";
	public static final String FM00024 = "FM00024";
	public static final String FM00025 = "FM00025";
	public static final String FM00026 = "FM00026";
	public static final String FM00027 = "FM00027";
	public static final String FM00028 = "FM00028";
	public static final String FM00029 = "FM00029";
	public static final String FM00030 = "FM00030";
	public static final String APP_FIELD_DEFINATION_NOT_FOUND = "FM00120";
	
}
